<?php
/*
Plugin Name: Bloga Pro Core
Description: Huge collection of custom widgets, neatly bundled into a single plugin. It's also a framework to code your own widgets to help you make any kind of page.
Version: 1.0.1
Text Domain: bloga
Domain Path: bloga/languages
Author: XLTHEME
Author URI: https://www.xltheme.com/
Plugin URI: http://www.xltheme.com/
License: GPL3
License URI: https://www.gnu.org/licenses/gpl-3.0.txt
*/

define('BLOGA_BUNDLE_BASE_FILE', __FILE__);
define( 'BLOGA_CORE_ROOT', untrailingslashit( plugin_dir_path( __FILE__ ) ) );


function xl_bloga_core_script() {
    
        if (!is_admin()) {
            // wp_enqueue_script('xl_owl_js', plugins_url('/../vendors/owl/owl.carousel.min.js', __FILE__), array('jquery'), '2.0.0', true);
            // wp_enqueue_script('xl_custom_js', plugins_url('/../assets/js/xl-logo-custom.js', __FILE__), array(), '1.0.0', true);
            // wp_enqueue_style('xl_owl_css', plugins_url('/../vendors/owl/assets/owl.carousel.css', __FILE__), array(), '2.0.0');
            // wp_enqueue_style('xl_slicon_css', plugins_url('/../vendors/slicon/css/simple-line-icons.css', __FILE__), array(), '2.2.2');
            wp_enqueue_style('xl_custom_css', plugins_url('/assets/css/xl-style.css', __FILE__), array(), '1.0.0');
        }
    }
    
    add_action('init', 'xl_bloga_core_script');


// Meta boxes
// Page
require_once BLOGA_CORE_ROOT . '/metabox/xl-meta-page.php';
// Event
require_once BLOGA_CORE_ROOT . '/metabox/xl-meta-event.php';
// Testimonials
require_once BLOGA_CORE_ROOT . '/metabox/xl-meta-testimonials.php';

// Post types
// Course
require_once BLOGA_CORE_ROOT . '/post-type/xl-courses.php';
// Events
require_once BLOGA_CORE_ROOT . '/post-type/xl-events.php';
// Testimonials
require_once BLOGA_CORE_ROOT . '/post-type/xl-testimonials.php';
// Portfolio
require_once BLOGA_CORE_ROOT . '/post-type/xl-portfolio.php';


// Elemontor Widget
// Course
require_once BLOGA_CORE_ROOT . '/elements/xl-course/plugin.php';
// Slider
require_once BLOGA_CORE_ROOT . '/elements/xl-slider/plugin.php';
// Blog
require_once BLOGA_CORE_ROOT . '/elements/xl-blog/plugin.php';
require_once BLOGA_CORE_ROOT . '/elements/xl-blog-featured-posts/plugin.php';
// Event
require_once BLOGA_CORE_ROOT . '/elements/xl-event/plugin.php';
// Partner
require_once BLOGA_CORE_ROOT . '/elements/xl-partner/plugin.php';
// Testimonials
require_once BLOGA_CORE_ROOT . '/elements/xl-testimonials/plugin.php';
// Portfolio
require_once BLOGA_CORE_ROOT . '/elements/xl-portfolio/plugin.php';
// Team
require_once BLOGA_CORE_ROOT . '/elements/xl-team/plugin.php';

// Helper Functions
require_once BLOGA_CORE_ROOT . '/elements/helper-functions.php';
// Inc
require_once BLOGA_CORE_ROOT . '/inc/xl-element-anywhere.php';