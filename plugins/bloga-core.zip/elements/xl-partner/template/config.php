<?php

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Switch Slider
 *
 * Elementor widget for switch slider
 *
 * @since 1.0.0
 */
class xl_partner_widget extends Widget_Base {

	public function get_name() {
		return 'xl-partner';
	} 

	public function get_title() {
		return __( 'Partner', 'bloga' );
	}

	public function get_icon() {
		return 'eicon-person';
	}

	public function get_categories() {
		return [ 'bloga' ];
	}

	/**
	 * A list of scripts that the widgets is depended in
	 * @since 1.3.0
	 **/
	public function get_script_depends() {
		return [ 'xl-partner' ];
	}

	protected function _register_controls() {

	    // Content options Start
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Partner Content', 'bloga' ),
			]
		);

        $this->add_control(
		    'title',
            [
                'label' => __( 'Partner Name', 'bloga' ),
                'type'  => Controls_Manager::TEXT,
                'default' => __('Partner Name', 'bloga' ),
            ]
	    );
        $this->add_control(
		    'sub_title',
		      	[
		          'label' => __( 'Sub Title', 'bloga' ),
		          'type'  => Controls_Manager::TEXT,
		          'default' => __('Nobis lucilius', 'bloga' ),
		    	]
        );

        $this->add_control(
            'partner_image',
            [
                'label' => __('Upload Partner Image', 'bloga'),
                'type' => Controls_Manager::MEDIA
            ]
        );

        $this->add_control(
		    'partner_description',
		      	[
		          'label' => __( 'Partner Description', 'bloga' ),
		          'type'  => Controls_Manager::WYSIWYG,
		          'default' => __( 'Corem ipsum dolor si amet consectetur adipisic ingelit sed do adipisicido executiv sunse pit lore kome.', 'bloga' ),
		      	]
        );

        $this->end_controls_section();
        // Content options End

        

        // Title Style
        $this->start_controls_section(
            'section_title_style',
            [
                'label' => __('Title Style', 'bloga' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label' => __('Title Color', 'bloga'),
                'type' => Controls_Manager::COLOR,
                'default' => '#302a34',
                'selectors' => [
                    '{{WRAPPER}} .xl-partner .title-sub-title .title' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'label' => __('Title Typography', 'bloga'),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .xl-partner .title-sub-title .title',
            ]
        );
        $this->add_control(
            'title_margin',
            [
                'label' => __('Margin', 'bloga'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .xl-partner .title-sub-title .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        // Sub Title Style
        $this->start_controls_section(
            'section_sub_title_style',
            [
                'label' => __('Sub Title Style', 'bloga'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'sub_title_color',
            [
                'label' => __('Sub Title Color', 'bloga'),
                'type' => Controls_Manager::COLOR,
                'default' => '#504f4f',
                'selectors' => [
                    '{{WRAPPER}} .xl-partner .title-sub-title .sub-title' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'sub_title_typography',
                'label' => __('Sub Title Typography', 'bloga'),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .xl-partner .title-sub-title .sub-title',
            ]
        );
        $this->add_control(
            'sub_title_margin',
            [
                'label' => __('Margin', 'bloga'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .xl-partner .title-sub-title .sub-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        // Partner Image
        $this->start_controls_section(
            'section_image_style',
            [
                'label' => __('Image Style', 'bloga'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'image_margin',
            [
                'label' => __('Margin', 'bloga'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .xl-partner .partner-img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        // Content Style
        $this->start_controls_section(
            'section_content_style',
            [
                'label' => __('Description Style', 'bloga'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'content_color',
            [
                'label' => __('Content Color', 'bloga'),
                'type' => Controls_Manager::COLOR,
                'default' => '#302a34',
                'selectors' => [
                    '{{WRAPPER}} .xl-partner .partner-description' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'label' => __('Typography', 'bloga'),
                'scheme' => Scheme_Typography::TYPOGRAPHY_2,
                'selector' => '{{WRAPPER}} .xl-partner .partner-description',
            ]
        );
        $this->add_control(
            'content_margin',
            [
                'label' => __('Margin', 'bloga'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .xl-partner .partner-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

	}

	protected function render() {
		require BLOGA_CORE_ROOT . '/elements/xl-partner/template/view.php';
	}

}
