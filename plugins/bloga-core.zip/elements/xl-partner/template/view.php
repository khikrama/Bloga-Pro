<?php
// Silence is golden.

    $settings = $this->get_settings();

?>

<div class="xl-partner">
    <div class="title-sub-title">
        <h4 class="title"><?php echo $settings['title']; ?></h4>
        <p class="sub-title"><?php echo $settings['sub_title']; ?></p>
    </div>
    <div class="partner-img">
        <img src="<?php echo $settings['partner_image']['url']; ?>" alt="<?php echo $settings['title']; ?>">   
    </div>
    <div class="partner-description">
        <?php echo $settings['partner_description']; ?>
    </div>
</div>