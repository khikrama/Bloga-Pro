<?php
// Silence is golden.

	$settings = $this->get_settings();

  // Global Options
	global $post;
 	// Prefix
  $prefix = '_xl_';

?>

    <section id="testimonial" class="testimonial">
        <div class="xl-testimonial xl-testimonial-1 owl-carousel owl-theme-">
            
                <?php
                    $testimonial = array(
                        'post_type' => 'testimonial',
                        'post_status' => 'publish',
                        'posts_per_page' => -1,
                    );
                    $testimonial_query = new WP_Query($testimonial);
                    if ($testimonial_query->have_posts()) :
                        while ($testimonial_query->have_posts()) :
                        $testimonial_query->the_post();

                    $testimony_image = get_post_meta($post->ID, $prefix . 'testimoni_image', true);
                    $name = get_post_meta($post->ID, $prefix . 'testimoni_name', true);
                    $designation = get_post_meta($post->ID, $prefix . 'testimoni_designation', true);
                ?>

                <div class="testimoni-wrapper text-center">
                    <?php if ($settings['testimoni_position'] == 'top') : ?>
                    <div class="content">
                        <span class="testimony"><?php the_content(); ?></span>
                    </div>
                    <?php endif; ?>
                        <div class="author">
                            <?php if ($testimony_image) : ?>
                                <img class="testimoni-image" src="<?php echo esc_url($testimony_image); ?>" alt="<?php the_title(); ?>">
                            <?php endif; ?>
                            
                        </div>

                        <div class="info">                    
                            <h4 class="name"><?php echo $name; ?></h4>
                            <p class="designation"><?php echo $designation; ?></p>
                        </div>

                        <?php if ($settings['testimoni_position'] == 'bottom') : ?>
                        <div class="content">
                            <span class="testimony"><?php the_content(); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                <?php endwhile;
                endif;
                wp_reset_postdata(); ?>

        </div><!-- /.xl-testimonial-1 -->              
    </section><!-- /.section -->


    <script type="text/javascript">
        jQuery(document).ready(function(){
            jQuery(".owl-carousel").owlCarousel({
                items: 1,
                loop: false,
                nav: <?php echo (($settings['navigation'] == 'both') || ($settings['navigation'] == 'arrows')) ? 'true' : 'false' ; ?>,
                navText: [
                        '<span class="fa fa-angle-left"></span>',
                        '<span class="fa fa-angle-right"></span>'
                    ],
                dots: <?php echo (($settings['navigation'] == 'both') || ($settings['navigation'] == 'dots')) ? 'true' : 'false' ; ?>,
                autoplay: <?php echo $settings['carousel_autoplay'] ?>,
                autoplayHoverPause: <?php echo $settings['carousel_autoplay_hover_pause'] ?>,
                loop: <?php echo $settings['carousel_autoplay_hover_pause'] ?>,
            });
        });
    </script>

