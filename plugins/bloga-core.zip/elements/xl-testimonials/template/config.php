<?php


use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Bloga Testimonial
 *
 * Elementor widget for Bloga Testimonial
 *
 * @since 1.0.0
 */
class xl_testimonial_1_widget extends Widget_Base {

	public function get_name() {
		return 'xl-testimonial';
	}

	public function get_title() {
		return __( 'Bloga testimonial 1', 'bloga' );
	}

	public function get_icon() {
		return 'eicon-testimonial';
	}

	public function get_categories() {
		return [ 'bloga' ];
	}

	/**
	 * A list of scripts that the widgets is depended in
	 * @since 1.3.0
	 **/
	public function get_script_depends() {
		return [ 'xl-testimonials' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'section_title_style',
			[
				'label' => __( 'Title Style', 'bloga' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
				[
					'name'     => 'title_typography',
					'label'    => __( 'Title Typography', 'bloga' ),
					'scheme'   => Scheme_Typography::TYPOGRAPHY_4,
					'selector' => '{{WRAPPER}} .xl-testimonial-1 .testimoni-wrapper .name',
				]
		);
		$this->add_control(
			'name_color',
			[
				'label'     => __( 'Title Color', 'bloga' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#182432',
				'selectors' => [
					'{{WRAPPER}} .xl-testimonial-1 .testimoni-wrapper .name' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_designation_style',
			[
				'label' => __( 'Designation Style', 'bloga' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
				[
					'name'     => 'designation_typography',
					'label'    => __( 'Designation Typography', 'bloga' ),
					'scheme'   => Scheme_Typography::TYPOGRAPHY_4,
					'selector' => '{{WRAPPER}} .xl-testimonial-1 .testimoni-wrapper .designation',
				]
		);
		$this->add_control(
			'designation_color',
			[
				'label'     => __( 'Designation Color', 'bloga' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#989898',
				'selectors' => [
					'{{WRAPPER}} .xl-testimonial-1 .testimoni-wrapper .designation' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'section_image_style',
            [
                'label' => __( 'Image Style', 'bloga' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'image_margin',
            [
                'label' => __('Margin', 'bloga'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'allowed_dimensions' => 'vertical',
                'placeholder' => [
                    'top' => '',
                    'right' => 'auto',
                    'bottom' => '',
                    'left' => 'auto',
                ],
                'selectors' => [
                    '{{WRAPPER}} .xl-testimonial-1 .testimoni-wrapper .testimoni-image' => 'margin-top: {{TOP}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'section_content_style',
			[
				'label' => __( 'Content Style', 'bloga' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'testimoni_position',
				[
					'label'     => __( 'Testimoni Position', 'bloga' ),
					'type'      => Controls_Manager::SELECT,
					'default'   => 'top',
					'options'   => [
						'top'		   => __('Top', 'bloga'),
						'bottom'       => __( 'Bottom', 'bloga' ),
					],
				]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
				[
					'name'     => 'testimoni_typography',
					'label'    => __( 'Testimoni Typography', 'bloga' ),
					'scheme'   => Scheme_Typography::TYPOGRAPHY_4,
					'selector' => '{{WRAPPER}} .xl-testimonial-1 .testimoni-wrapper .testimony',
				]
		);
		$this->add_control(
			'testimoni_color',
			[
				'label'     => __( 'Testimoni Color', 'bloga' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#676767',
				'selectors' => [
					'{{WRAPPER}} .xl-testimonial-1 .testimoni-wrapper .testimony' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		// Nav Style
        $this->start_controls_section(
            'section_style_navigation',
            [
                'label' => __('Navigation', 'bloga'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'navigation',
            [
                'label' => __('Navigation', 'bloga'),
                'type' => Controls_Manager::SELECT,
                'default' => 'both',
                'options' => [
                    'both' => __('Arrows and Dots', 'bloga'),
                    'arrows' => __('Arrows', 'bloga'),
                    'dots' => __('Dots', 'bloga'),
                    'none' => __('None', 'bloga'),
                ],
                'frontend_available' => true,
            ]
        );

        $this->add_control(
            'heading_style_arrows',
            [
                'label' => __('Arrows', 'bloga'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'navigation' => ['arrows', 'both'],
                ],
            ]
        );

        $this->add_control(
            'arrows_size',
            [
                'label' => __('Arrows Size', 'bloga'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 20,
                        'max' => 60,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .xl-testimonial.owl-carousel .owl-nav' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'navigation' => ['arrows', 'both'],
                ],
            ]
        );

        $this->add_control(
            'arrows_color',
            [
                'label' => __('Arrows Color', 'bloga'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .xl-testimonial.owl-carousel .owl-nav' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'navigation' => ['arrows', 'both'],
                ],
            ]
        );

        $this->add_control(
            'heading_style_dots',
            [
                'label' => __('Dots', 'bloga'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'navigation' => ['dots', 'both'],
                ],
            ]
        );
        $this->add_control(
            'dots_size',
            [
                'label' => __('Dots Size', 'bloga'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 5,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .xl-testimonial.owl-carousel .owl-dot' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'navigation' => ['dots', 'both'],
                ],
            ]
        );
        $this->add_control(
            'dots_color',
            [
                'label' => __('Dots Color', 'bloga'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .xl-testimonial.owl-carousel .owl-dot' => 'background: {{VALUE}};',
                ],
                'condition' => [
                    'navigation' => ['dots', 'both'],
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_additional_options',
            [
                'label' => __('Additional Options', 'bloga'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'carousel_autoplay',
            [
                'label' => __('Auto Play', 'bloga'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'false',
            ]
        );
        $this->add_control(
            'carousel_autoplay_hover_pause',
            [
                'label' => __('Auto Play Hover Pause', 'bloga'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'false',
            ]
        );
        $this->add_control(
            'carousel_infinity_loop',
            [
                'label' => __('Infinity Loop', 'bloga'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'false',
            ]
        );

        $this->end_controls_section();

	}

	protected function render() {
		require BLOGA_CORE_ROOT . '/elements/xl-testimonials/template/view.php';
	}
}
