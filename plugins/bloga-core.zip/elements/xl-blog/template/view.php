<?php

	$settings = $this->get_settings();

?>

	<section id="blog" class="xl-custom-blog">
         <div class="row">
                <?php
                    $post_formats = array('audio', 'image', 'video', 'link', 'gallery');
                        $blog = array(
                            'post_type'         => 'post',
                            'post_status'       => 'publish',
                            'posts_per_page'    => 3,
                            'ignore_sticky_posts' => 1,
                             'tax_query' => array( array(
                                'taxonomy' => 'post_format',
                                'field' => 'slug',
                                'terms' => array('post-format-aside', 'post-format-gallery', 'post-format-link', 'post-format-image', 'post-format-quote', 'post-format-status', 'post-format-audio', 'post-format-chat', 'post-format-video'),
                                'operator' => 'NOT IN'
                               ) 
                            ),
                        );

                    $blog_query = new WP_Query( $blog );
                        if($blog_query->have_posts()):
                            while($blog_query->have_posts()): 
                                $blog_query->the_post(); 
                ?>

                <div class="col-md-4">
                    <article id="post-<?php the_ID(); ?>" <?php post_class('custom-post'); ?>>
                        <?php if (has_post_thumbnail()) : ?>
                        <div class="post-thumb-title">                            
                            <figure class="post-thumbnail">
                                <?php the_post_thumbnail(); ?>
                            </figure>                            

                            <header class="entry-header">
                                <h2 class="entry-title">
                                    <a href="<?php the_permalink(); ?>"><?php echo wp_trim_words(get_the_title(), 6, '...'); ?></a>
                                </h2>
                            </header><!-- .entry-header -->
                        </div>
                        <?php else : ?>
                        <header class="no-thumb entry-header">
                            <h2 class="entry-title">
                                <a href="<?php the_permalink(); ?>"><?php echo wp_trim_words(get_the_title(), 6, '...'); ?></a>
                            </h2>
                        </header><!-- .entry-header -->
                        <?php endif; ?>

                        <div class="blog-details">
                        <?php if ( 'post' === get_post_type() ) : ?>
                            <div class="entry-meta">
                                <?php if ('yes' == $settings['show_category']) : ?>
                                <div class="category">
                                    <i class="fa fa-folder-open"></i>
                                    <?php the_category(', '); ?>
                                </div>
                                <?php endif;?>

                                <?php if ('yes' == $settings['show_author']) : ?>
                                <div class="author">
                                    <i class="fa fa-user"></i>
                                    <a href="<?php get_the_author_link(); ?>"><?php the_author(); ?></a>
                                </div>
                                <?php endif; ?>

                                <?php if ('yes' == $settings['show_views']) : ?>
                                <div class="views">
                                    <i class="fa fa-eye"></i>
                                    <a href="#"><?php echo getPostViews(get_the_ID()); ?></a>
                                </div>
                                <?php endif; ?>

                                <?php if ('yes' == $settings['show_comments']) : ?>
                                <div class="comments">
                                    <i class="fa fa-comment"></i>
                                    <a href="<?php the_permalink(); ?>">
                                        <?php comments_number('No Comment ', '1 Comment', '% Comments'); ?>
                                    </a>
                                </div>
                                <?php endif; ?>
                            </div><!-- .entry-meta -->
                        <?php endif; ?>


                        <?php if (!in_array(get_post_format(), $post_formats)):?>
                            <div class="entry-content">
                                <p><?php echo wp_trim_words( get_the_content(),35, ''); ?></p>
                            </div><!-- .entry-content -->
                        <?php endif; ?>

                        <footer class="entry-footer">
                            <div class="content-btn">
                                <a class="elementor-button" href="<?php the_permalink(); ?>"><?php esc_html_e('Read More', 'bloga');?> <i class="fa fa-angle-right"></i>
                                    
                                </a>                    
                            </div>
                        </footer> <!-- .entry-footer -->
                        </div>
                    </article><!-- #post-## -->
                </div> <!-- /.col-md-3 -->

            <?php endwhile; wp_reset_postdata(); endif; ?>
        </div><!-- /.row -->     
    </section> <!-- /.section -->

