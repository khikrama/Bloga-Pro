<?php





use Elementor\Widget_Base;

use Elementor\Controls_Manager;

use Elementor\Repeater;

use Elementor\Scheme_Color;

use Elementor\Group_Control_Typography;

use Elementor\Scheme_Typography;

use Elementor\Group_Control_Border;



if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly



/**

 * Elementor Switch Slider

 *

 * Elementor widget for switch slider

 *

 * @since 1.0.0

 */

class xl_slider_widget extends Widget_Base {



	public function get_name() {

		return 'xl-slider';

	} 



	public function get_title() {

		return __( 'Slider', 'bloga' );

	}



	public function get_icon() {

		return 'eicon-slider-video';

	}



	public function get_categories() {

		return [ 'bloga' ];

	}



	/**

	 * A list of scripts that the widgets is depended in

	 * @since 1.3.0

	 **/

	public function get_script_depends() {

		return [ 'xl-slider' ];

	}



	protected function _register_controls() {



	    // Content options Start

		$this->start_controls_section(

			'section_content',

			[

				'label' => __( 'Slider Content', 'bloga' ),

			]

		);





	    $repeater = new Repeater();

	    $repeater->add_control(

		    'title',

		      	[

		          'label' => __( 'Slider Title', 'bloga' ),

		          'type'  => Controls_Manager::TEXTAREA,

		          'default' => __('Lorem ipsum dolor sit amet duo', 'bloga' ),

		    	]

	    );



		$repeater->add_control(

		    'slider_content',

		      	[

		          'label' => __( 'Slider Description', 'bloga' ),

		          'type'  => Controls_Manager::WYSIWYG,

		          'default' => __( 'Corem ipsum dolor si amet consectetur adipisic ingelit sed do adipisicido executiv sunse pit lore kome.', 'bloga' ),

		      	]

        );



        $repeater->add_control(

            'btn_text',

            [

                'label' => __('Button Text', 'bloga'),

                'type' => Controls_Manager::TEXT,

                'default' => __('View More', 'bloga'),

                'placeholder' => __('View More', 'bloga'),

            ]

        );



        $repeater->add_control(

            'btn_link',

            [

                'label' => __('Link', 'bloga'),

                'type' => Controls_Manager::URL,

                'placeholder' => 'https://xltheme.com',

                'default' => [

                    'url' => '#',

                ],

            ]

        );



		$this->add_control(

		    'slider_option',

		      [

		          'label'       => __( 'Slider Options', 'bloga' ),

		          'type'        => Controls_Manager::REPEATER,

		          'show_label'  => true,

		          'default'     => [

		              [

		                'title' => __('Lorem ipsum dolor sit amet duo', 'bloga' ),

		                'slider_content' => 'Corem ipsum dolor si amet consectetur adipisic ingelit sed do adipisicido executiv sunse pit lore kome.',

                        'btn-text' => 'View More',

                        'btn-link' => 'https://www.duetsoft.com',

		              ]

		          ],

		          'fields'      => array_values( $repeater->get_controls() ),

		          'title_field' => '{{{title}}}',

		      ]

		  );



        $this->end_controls_section();

        // Content options End



        $this->start_controls_section(

            'section_additional_options',

            [

                'label' => __('Additional Options', 'elementor'),

            ]

        );



        $this->add_control(

            'navigation',

            [

                'label' => __('Navigation', 'elementor'),

                'type' => Controls_Manager::SELECT,

                'default' => 'both',

                'options' => [

                    'both' => __('Arrows and Dots', 'elementor'),

                    'arrows' => __('Arrows', 'elementor'),

                    'dots' => __('Dots', 'elementor'),

                    'none' => __('None', 'elementor'),

                ],

                'frontend_available' => true,

            ]

        );



        $this->add_control(

            'slider_interval',

            [

                'label' => __('Slider Interval', 'elementor'),

                'type' => Controls_Manager::NUMBER,

                'default' => 10000,

                'frontend_available' => true,

            ]

        );



        $this->end_controls_section();




        // General Style

        $this->start_controls_section(

            'section_general_style',

            [

                'label' => __('General Style', 'bloga' ),

                'tab'   => Controls_Manager::TAB_STYLE,

            ]

        );

        $this->add_responsive_control(
            'content_alignment',
            [
                'label' => __( 'Alignment', 'elementor' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'elementor' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'elementor' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'elementor' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .carousel-indicators' => 'text-align: {{VALUE}};',
                    '{{WRAPPER}} .carousel-inner' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();




        // Title Style

        $this->start_controls_section(

            'section_title_style',

            [

                'label' => __('Title Style', 'bloga' ),

                'tab'   => Controls_Manager::TAB_STYLE,

            ]

        );

        $this->add_control(

            'title_color',

            [

                'label' => __('Slider Title Color', 'bloga'),

                'type' => Controls_Manager::COLOR,

                'default' => '#fff',

                'selectors' => [

                    '{{WRAPPER}} .carousel .carousel-inner .single-slide .title' => 'color: {{VALUE}};',

                ],

            ]

        );

        $this->add_group_control(

            Group_Control_Typography::get_type(),

            [

                'name' => 'title_typography',

                'label' => __('Title Typography', 'bloga'),

                'scheme' => Scheme_Typography::TYPOGRAPHY_1,

                'selector' => '{{WRAPPER}} .carousel .carousel-inner .single-slide .title',

            ]

        );

        $this->add_control(

            'title_margin',

            [

                'label' => __('Margin', 'bloga'),

                'type' => Controls_Manager::DIMENSIONS,

                'size_units' => ['px', 'em', '%'],

                'selectors' => [

                    '{{WRAPPER}} .carousel .carousel-inner .single-slide .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],

            ]

        );

        $this->end_controls_section();



        // Content Style

        $this->start_controls_section(

            'section_content_style',

            [

                'label' => __('Content Style', 'bloga'),

                'tab' => Controls_Manager::TAB_STYLE,

            ]

        );

        $this->add_control(

            'content_color',

            [

                'label' => __('Slider Content Color', 'bloga'),

                'type' => Controls_Manager::COLOR,

                'default' => '#fff',

                'selectors' => [

                    '{{WRAPPER}} .carousel .carousel-inner .single-slide .content' => 'color: {{VALUE}};',

                ],

            ]

        );

        $this->add_group_control(

            Group_Control_Typography::get_type(),

            [

                'name' => 'content_typography',

                'label' => __('Content Typography', 'bloga'),

                'scheme' => Scheme_Typography::TYPOGRAPHY_2,

                'selector' => '{{WRAPPER}} .carousel .carousel-inner .single-slide .content',

            ]

        );

        $this->add_control(

            'content_margin',

            [

                'label' => __('Margin', 'bloga'),

                'type' => Controls_Manager::DIMENSIONS,

                'size_units' => ['px', 'em', '%'],

                'selectors' => [

                    '{{WRAPPER}} .carousel .carousel-inner .single-slide .content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],

            ]

        );

        $this->end_controls_section();



        // Button Style

        $this->start_controls_section(

            'section_button_style',

            [

                'label' => __('Button Style', 'bloga'),

                'tab' => Controls_Manager::TAB_STYLE,

            ]

        );

        $this->add_group_control(

            Group_Control_Typography::get_type(),

            [

                'name' => 'button_typography',

                'label' => __('Button Typography', 'bloga'),

                'scheme' => Scheme_Typography::TYPOGRAPHY_3,

                'selector' => '{{WRAPPER}} a.elementor-button, {{WRAPPER}} .elementor-button',

            ]

        );

        $this->add_control(

            'button_padding',

            [

                'label' => __('Button Padding', 'bloga'),

                'type' => Controls_Manager::DIMENSIONS,

                'size_units' => ['px', 'em', '%'],

                'selectors' => [

                    '{{WRAPPER}} .carousel .carousel-inner .single-slide .slider-button .btn-slider' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],

            ]

        );

        $this->add_control(

            'button_margin',

            [

                'label' => __('Margin', 'bloga'),

                'type' => Controls_Manager::DIMENSIONS,

                'size_units' => ['px', 'em', '%'],

                'selectors' => [

                    '{{WRAPPER}} .carousel .carousel-inner .single-slide .slider-button .btn-slider' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],

            ]

        );



        $this->start_controls_tabs('tabs_button_style');

        $this->start_controls_tab(

            'tab_button_normal',

            [

                'label' => __('Normal', 'elementor'),

            ]

        );

        $this->add_control(

            'background_color',

            [

                'label' => __('Background Color', 'elementor'),

                'type' => Controls_Manager::COLOR,

                'scheme' => [

                    'type' => Scheme_Color::get_type(),

                    'value' => Scheme_Color::COLOR_4,

                ],

                'selectors' => [

                    '{{WRAPPER}} a.elementor-button, {{WRAPPER}} .elementor-button' => 'background-color: {{VALUE}};',

                ],

            ]

        );

        $this->add_control(

            'button_color',

            [

                'label' => __('Button Color', 'bloga'),

                'type' => Controls_Manager::COLOR,

                'default' => '#fff',

                'selectors' => [

                    '{{WRAPPER}} a.elementor-button, {{WRAPPER}} .elementor-button' => 'color: {{VALUE}};',

                ],

            ]

        );        

        $this->add_group_control(

            Group_Control_Border::get_type(),

            [

                'name' => 'border',

                'label' => __('Border', 'bloga'),

                'placeholder' => '1px',

                'default' => '1px',

                'selector' => '{{WRAPPER}} .elementor-button',

                'separator' => 'before',

            ]

        );

        $this->add_control(

            'border_radius',

            [

                'label' => __('Border Radius', 'bloga'),

                'type' => Controls_Manager::DIMENSIONS,

                'size_units' => ['px', '%'],

                'selectors' => [

                    '{{WRAPPER}} a.elementor-button, {{WRAPPER}} .elementor-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],

            ]

        );

        $this->end_controls_tab();



        $this->start_controls_tab(

            'tab_button_hover',

            [

                'label' => __('Hover', 'elementor'),

            ]

        );

        $this->add_control(

            'hover_color',

            [

                'label' => __('Text Color', 'elementor'),

                'type' => Controls_Manager::COLOR,

                'selectors' => [

                    '{{WRAPPER}} a.elementor-button:hover, {{WRAPPER}} .elementor-button:hover' => 'color: {{VALUE}};',

                ],

            ]

        );

        $this->add_control(

            'button_background_hover_color',

            [

                'label' => __('Background Color', 'elementor'),

                'type' => Controls_Manager::COLOR,

                'selectors' => [

                    '{{WRAPPER}} a.elementor-button:hover, {{WRAPPER}} .elementor-button:hover' => 'background-color: {{VALUE}};',

                ],

            ]

        );

        $this->add_control(

            'button_hover_border_color',

            [

                'label' => __('Border Color', 'elementor'),

                'type' => Controls_Manager::COLOR,

                'condition' => [

                    'border_border!' => '',

                ],

                'selectors' => [

                    '{{WRAPPER}} a.elementor-button:hover, {{WRAPPER}} .elementor-button:hover' => 'border-color: {{VALUE}};',

                ],

            ]

        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();





        // Nav Style

        $this->start_controls_section(

            'section_style_navigation',

            [

                'label' => __('Navigation', 'elementor'),

                'tab' => Controls_Manager::TAB_STYLE,

                'condition' => [

                    'navigation' => ['arrows', 'dots', 'both'],

                ],

            ]

        );



        $this->add_control(

            'heading_style_arrows',

            [

                'label' => __('Arrows', 'elementor'),

                'type' => Controls_Manager::HEADING,

                'separator' => 'before',

                'condition' => [

                    'navigation' => ['arrows', 'both'],

                ],

            ]

        );



        $this->add_control(

            'arrows_position',

            [

                'label' => __('Arrows Position', 'elementor'),

                'type' => Controls_Manager::SELECT,

                'default' => 'inside',

                'options' => [

                    'inside' => __('Inside', 'elementor'),

                    'outside' => __('Outside', 'elementor'),

                ],

                'condition' => [

                    'navigation' => ['arrows', 'both'],

                ],

            ]

        );



        $this->add_control(

            'arrows_size',

            [

                'label' => __('Arrows Size', 'elementor'),

                'type' => Controls_Manager::SLIDER,

                'range' => [

                    'px' => [

                        'min' => 20,

                        'max' => 60,

                    ],

                ],

                'selectors' => [

                    '{{WRAPPER}} .xl-hero-unit .arrows i' => 'font-size: {{SIZE}}{{UNIT}};',

                ],

                'condition' => [

                    'navigation' => ['arrows', 'both'],

                ],

            ]

        );



        $this->add_control(

            'arrows_color',

            [

                'label' => __('Arrows Color', 'elementor'),

                'type' => Controls_Manager::COLOR,

                'selectors' => [

                    '{{WRAPPER}} .xl-hero-unit .arrows i' => 'color: {{VALUE}};',

                ],

                'condition' => [

                    'navigation' => ['arrows', 'both'],

                ],

            ]

        );



        $this->add_control(

            'heading_style_dots',

            [

                'label' => __('Dots', 'elementor'),

                'type' => Controls_Manager::HEADING,

                'separator' => 'before',

                'condition' => [

                    'navigation' => ['dots', 'both'],

                ],

            ]

        );



        $this->add_control(

            'dots_position',

            [

                'label' => __('Dots Position', 'elementor'),

                'type' => Controls_Manager::SELECT,

                'default' => 'outside',

                'options' => [

                    'outside' => __('Outside', 'elementor'),

                    'inside' => __('Inside', 'elementor'),

                ],

                'condition' => [

                    'navigation' => ['dots', 'both'],

                ],

            ]

        );



        $this->add_control(

            'dots_size',

            [

                'label' => __('Dots Size', 'elementor'),

                'type' => Controls_Manager::SLIDER,

                'range' => [

                    'px' => [

                        'min' => 5,

                        'max' => 50,

                    ],

                ],

                'selectors' => [

                    '{{WRAPPER}} .xl-hero-unit .carousel-indicators li' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};border-radius: 50%;',

                ],

                'condition' => [

                    'navigation' => ['dots', 'both'],

                ],

            ]

        );



        $this->add_control(

            'dots_color',

            [

                'label' => __('Dots Color', 'elementor'),

                'type' => Controls_Manager::COLOR,

                'selectors' => [

                    '{{WRAPPER}} .xl-hero-unit .carousel-indicators li' => 'border-color: {{VALUE}};',

                    '{{WRAPPER}} .xl-hero-unit .carousel-indicators li.active' => 'background-color: {{VALUE}};',

                ],

                'condition' => [

                    'navigation' => ['dots', 'both'],

                ],

            ]

        );



        $this->end_controls_section();







	}



	protected function render() {

		require BLOGA_CORE_ROOT . '/elements/xl-slider/template/view.php';

	}





}

