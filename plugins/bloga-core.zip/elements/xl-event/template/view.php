<?php
$settings = $this->get_settings();
global $post;

?>

<div class="xl-event-wraper">
    <div class="row">
        <?php
        $event = array(
            'post_type' => 'event',
            'post_status' => 'publish',
            'posts_per_page' => -1,
        );
        $event_query = new WP_Query($event);
        if ($event_query->have_posts()) :
            while ($event_query->have_posts()) :
            $event_query->the_post();

            $meta_event_date = get_post_meta($post->ID, '_xl_event_date', true);
            $meta_event_start_time = get_post_meta($post->ID, '_xl_event_start_time', true);
            $meta_event_end_time = get_post_meta($post->ID, '_xl_event_end_time', true);
            $meta_event_location = get_post_meta($post->ID, '_xl_event_location', true);
        ?>
        <div class="col-md-12">
            <div class="xl-event">
                <div class="row">
                    <div class="col-md-4">
                        <div class="thumb-date">
                            <?php if (has_post_thumbnail()) {
                                the_post_thumbnail();
                            } else { ?>
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/course-placeholder.jpg" alt="<?php the_title(); ?>" />
                            <?php } ?>

                            <div class="edate-time">
                                <div class="date">
                                    <?php $date = date_create($meta_event_date); ?>
                                    <div class="month"><?php echo date_format($date, "M"); ?></div>
                                    <div class="day"><?php echo date_format($date, "d"); ?></div>
                                </div>
                                <div class="time">
                                    <?php echo $meta_event_start_time; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <h2 class="entry-title"><?php echo the_title(); ?></h2>
                        <div class="event-info">
                            <div class="event-date">
                                <i class="fa fa-calendar"></i>
                                <?php echo $meta_event_date; ?>
                            </div>
                            <div class="event-time">
                                <i class="fa fa-clock-o"></i>
                                <?php echo $meta_event_start_time; ?> - <?php echo $meta_event_end_time; ?>
                            </div>
                            <div class="event-location">
                                <i class="fa fa-map-marker"></i>
                                <?php echo $meta_event_location; ?>
                            </div>
                        </div>
                        <div class="event-details-btn">
                            <a href="<?php echo get_permalink(); ?>" class="btn elementor-button btn-event">More Details</a>
                        </div>
                    </div>
                </div>
            </div><!--/.single-course-->
        </div><!--/.col-md-4-->
        <?php endwhile; endif; wp_reset_postdata(); ?>

    </div>
</div>