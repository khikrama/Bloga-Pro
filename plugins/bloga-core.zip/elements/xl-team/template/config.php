<?php


use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Team
 *
 * Elementor widget for team
 *
 * @since 1.0.0
 */
class xl_team_widget extends Widget_Base {

	public function get_name() {
		return 'xl-team';
	} 

	public function get_title() {
		return __( 'Bloga Team', 'bloga' );
	}

	public function get_icon() {
		return 'eicon-person';
	}

	public function get_categories() {
		return [ 'bloga' ];
	}

	/**
	 * A list of scripts that the widgets is depended in
	 * @since 1.3.0
	 **/
	public function get_script_depends() {
		return [ 'xl-team' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Team Content', 'bloga' ),
			]
		);

		$this->add_control(
	       'team_image',
		        [
		          'label' => __( 'Upload Team Image', 'bloga' ),
		          'type'  => Controls_Manager::MEDIA
		        ]
	    );

	    $this->add_control(
		    'team_name',
		      	[
		          'label' => __( 'Name', 'bloga' ),
		          'type'  => Controls_Manager::TEXT,
		          'default' => __( 'Johan Doe', 'bloga' ),
		    	]
	    );


	   	$this->add_control(
		    'designation',
		      	[
		          'label' => __( 'Designation', 'bloga' ),
		          'type'  => Controls_Manager::TEXT,
		          'default' => __( 'Developer', 'bloga' ),
		      	]
		);

		$this->add_control(
		    'content',
		      	[
		          'label' => __( 'Description', 'bloga' ),
		          'type'  => Controls_Manager::TEXTAREA,
		          'default' => __( 'Lorem ipsum dolor sit amet, ad mea mollis iracundia, admodum theophrastus reprehendunt ne vis.', 'bloga' ),
		      	]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_social',
			[
				'label' => __( 'Team Social', 'bloga' ),
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label' => __( 'Social Profile', 'bloga' ),
				'type'  => Controls_Manager::TEXT,
				'default' => __( 'Facebook', 'bloga' ),
			]
		);

		$repeater->add_control(
			'social_link',
			[
				'label' => __( 'Link', 'bloga' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'https://www.facebook.com/xltheme', 'bloga' ),
			]
		);

		$repeater->add_control(
			'social_icon',
			[
				'label' => __( 'Icon', 'bloga' ),
				'type' => Controls_Manager::ICON,
				'default' => 'fa fa-facebook',
			]
		);


		$this->add_control(
			'social_share',
			[
				'label'       => __( 'Social Share', 'bloga' ),
				'type'        => Controls_Manager::REPEATER,
				'show_label'  => true,
				'default'     => [
					[
					'social_link' => __( 'https://www.facebook.com/xltheme', 'bloga' ),
					'social_icon' => 'fa fa-facebook',
		
					]
				],
				'fields'      => array_values( $repeater->get_controls() ),
				'title_field' => '{{{title}}}',
			]
		);

		$this->end_controls_section();



		$this->start_controls_section(
			'general_style',
			[
				'label' => __( 'General Options', 'bloga' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'team_align',
			[
				'label'     => __( 'Alignment', 'bloga' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'center',
				'options' => [
					'left' => [
						'title' => __( 'Left', 'elementor' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'elementor' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'elementor' ),
						'icon' => 'fa fa-align-right',
					],
					'justify' => [
						'title' => __( 'Justified', 'elementor' ),
						'icon' => 'fa fa-align-justify',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .team-container .team-each-wrap' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'title_style',
			[
				'label' => __( 'Title Options', 'bloga' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
				[
					'name'     => 'title_typography',
					'label'    => __( 'Title Typography', 'bloga' ),
					'scheme'   => Scheme_Typography::TYPOGRAPHY_4,
					'selector' => '{{WRAPPER}} .team-container .team-each-wrap .team-info .team-title',
				]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => __( 'Title Color', 'bloga' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#333',
				'selectors' => [
					'{{WRAPPER}} .team-container .team-each-wrap .team-info .team-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_space',
			[
				'label' => __( 'Title Margin', 'bloga' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'allowed_dimensions' => 'vertical',
                'placeholder' => [
                    'top' => '',
                    'right' => 'auto',
                    'bottom' => '',
                    'left' => 'auto',
                ],
				'selectors' => [
					'{{WRAPPER}} .team-container .team-each-wrap .team-info .team-title' => 'margin-top: {{TOP}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'Designation_style',
			[
				'label' => __( 'Designation Options', 'bloga' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
				[
					'name'     => 'designation_typography',
					'label'    => __( 'Designation Typography', 'bloga' ),
					'scheme'   => Scheme_Typography::TYPOGRAPHY_4,
					'selector' => '{{WRAPPER}} .team-container .team-each-wrap .team-info .team-designation',
				]
		);

		$this->add_control(
			'designation_color',
			[
				'label'     => __( 'Desgination Color', 'bloga' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#333',
				'selectors' => [
					'{{WRAPPER}} .team-container .team-each-wrap .team-info .team-designation' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'description_style',
			[
				'label' => __( 'Description Options', 'bloga' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'desc_typography',
				'label'    => __( 'Description Typography', 'bloga' ),
				'scheme'   => Scheme_Typography::TYPOGRAPHY_4,
				'selector' => '{{WRAPPER}} .team-container .team-content',
			]
		);

		$this->add_control(
			'desc_color',
			[
				'label'     => __( 'Description Color', 'bloga' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .team-container .team-content' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'desc_margin',
			[
				'label' => __( 'Margin', 'bloga' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'allowed_dimensions' => 'vertical',
                'placeholder' => [
                    'top' => '',
                    'right' => 'auto',
                    'bottom' => '',
                    'left' => 'auto',
                ],
				'selectors' => [
					'{{WRAPPER}} .team-container .team-content' => 'margin-top: {{TOP}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'icon_style',
			[
				'label' => __( 'Social Options', 'bloga' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'icon_size',
			[
				'label' => __( 'Icon Font Size', 'bloga' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 8,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}}  .team-container .team-each-wrap .team-social a' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_padding',
			[
				'label' => __( 'Padding', 'elementor' ),
				'type' => Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .team-container .team-each-wrap .team-social a' => 'padding: {{SIZE}}{{UNIT}};',
				],
				'default' => [
					'unit' => 'em',
				],
				'tablet_default' => [
					'unit' => 'em',
				],
				'mobile_default' => [
					'unit' => 'em',
				],
				'range' => [
					'em' => [
						'min' => 0,
						'max' => 5,
					],
				],
			]
		);

		$this->add_responsive_control(
			'icon_spacing',
			[
				'label' => __( 'Icon Spacing', 'bloga' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 40,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .team-container .team-each-wrap .team-social a:not(:last-child)' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
            'border_radius',
            [
                'label' => __( 'Icon Border Radius', 'bloga' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .team-container .team-each-wrap .team-social a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


		$this->add_control(
			'icon_color',
			[
				'label'     => __( 'Icon Color', 'bloga' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8c8c8c',
				'selectors' => [
					'{{WRAPPER}} .team-container .team-each-wrap .team-social a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_bg_color',
			[
				'label'     => __( 'Icon Bg Color', 'bloga' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f5f5f5',
				'selectors' => [
					'{{WRAPPER}} .team-container .team-each-wrap .team-social a' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_hover_color',
			[
				'label'     => __( 'Icon Hover Color', 'bloga' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => [
					'{{WRAPPER}} .team-container .team-each-wrap .team-social a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_hover_bg_color',
			[
				'label'     => __( 'Icon Hover Background Color', 'bloga' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#255cdc',
				'selectors' => [
					'{{WRAPPER}} .team-container .team-each-wrap .team-social a:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

	$this->end_controls_section();
	}

	protected function render() {
		require BLOGA_CORE_ROOT . '/elements/xl-team/template/view.php';
	}


}
