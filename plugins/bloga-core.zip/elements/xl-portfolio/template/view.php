<?php
// Silence is golden.

    $settings = $this->get_settings();

   	// Global Options
	global $post;

?>

	<section id="portfolio" class="xl-portfolio">

        <?php
            $data = [];
            $terms = get_terms('filters');
            $count = count($terms);
        ?>

        <?php if ($settings['filter_enable']):?>
        <ul class="portfolio-filter controls">
            <li class="control" data-filter="all">Show All</li>
               <?php
               foreach ( $terms as $term ) {
                    $termname = strtolower($term->name);  
                    $termname = str_replace(" ", "_", $termname);
                    if(!in_array($termname, $data)){
                            $data[] = $termname;
                    }
                    ?>
                    <li class="control" data-filter=".<?php echo $termname;?>"><?php echo $term->name; ?></li>
                    <?php
               }
               ?>
        </ul>
        <?php endif; ?>


        <div class="row mixitup-container">
            <?php

                $portfolio = array(
                    'post_type'         => 'portfolio',
                    'post_status'       => 'publish',
                    'posts_per_page'    => $settings['no_of_item']['size'],
                );
                $i= 0;  $i < $settings['no_of_item']['size']; $i++;
                $portfolio_query = new WP_Query( $portfolio );
                if($portfolio_query->have_posts()):
                    while($portfolio_query->have_posts()): 
                        $portfolio_query->the_post(); 

                $cat_list = get_the_terms(get_the_ID(), 'filters');
               
            ?>
                <div class="col-md-<?php echo $settings['grid_layout'];?> col-sm-6 item mix <?php foreach($cat_list as $cat ): echo strtolower(str_replace(" ", "_", $cat->name)).' '; endforeach;?>" data-order="<?php echo $i; ?>"
                >
                    <figure class="overlay">
                        <div class="thumb-img">
                            <?php $item_image = get_post_meta( $post->ID, '_xl_portfolio_img', true ); ?>
                            <img src="<?php echo esc_url($item_image); ?>" alt="<?php the_title(); ?>">      
                        </div>
                        <figcaption class="overlay-panel">
                            <div class="link-icon">
                                <?php 
                                    $large_image = get_post_meta( $post->ID, '_xl_large_portfolio_img', true );
                                ?>
                                <a class="icon-search" data-elementor-open-lightbox="yes" href="<?php echo $large_image ? esc_url($large_image) : $item_image; ?>">
                                    <i class='fa fa-plus'></i>
                                </a>
                                <a href="<?php the_permalink();?>" class="icon-link">
                                    <i class='fa fa-link'></i>
                                </a>
                            </div>

                            <div class="portfolio-content">
                                <h4 class="title"><?php the_title(); ?></h4>
                                <?php $skill = get_post_meta( $post->ID, '_xl_project_skill', true ); ?>
                                <p class="xl-skills"><?php echo $skill;?></p>
                            </div>
                        </figcaption>                        
                    </figure>
                </div> <!-- /.col-md-3 -->
                <?php $i++; ?>

            <?php endwhile; wp_reset_postdata();  endif; ?>
            </div><!-- /.row -->
    </section> <!-- /.section -->