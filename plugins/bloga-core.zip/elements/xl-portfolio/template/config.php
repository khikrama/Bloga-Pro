<?php

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Bloga Portfolio
 *
 * Elementor widget for bloga portfolio
 *
 * @since 1.0.0
 */
class xl_portfolio_widget extends Widget_Base {

	public function get_name() {
		return 'xl-portfolio';
	}

	public function get_title() {
		return __( 'Bloga Portfolio', 'bloga' );
	}

	public function get_icon() {
		return 'eicon-apps';
	}

	public function get_categories() {
		return [ 'bloga' ];
	}

	/**
	 * A list of scripts that the widgets is depended in
	 * @since 1.3.0
	 **/
	public function get_script_depends() {
		return [ 'xl-portfolio' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'item_layout',
			[
				'label' => __( 'Layout', 'bloga' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'grid_layout',
				[
					'label'     => __( 'Select Column', 'bloga' ),
					'type'      => Controls_Manager::SELECT,
					'default'   => '4',
					'options'   => [
						'3'     => __( 'Four Column', 'bloga' ),
						'4'     => __( 'Three Column', 'bloga' ),
						'6'     => __( 'Two Column', 'bloga' ),
					],
				]
		);

		$this->add_control(
			'no_of_item',
				[
					'label'     => __( 'No of Items', 'bloga' ),
					'type'      => Controls_Manager::SLIDER,
					'default' => [
						'size' => 6,
					],
					'range'  => [
						'px' => [
							'min' => 1,
							'max' => 20,
						],
					],
				]
		);

		$this->add_control(
			'filter_enable',
			[
				'label'     => __( 'Filter Enable/Disable', 'bloga' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'yes'    => __( 'Enable', 'bloga' ),
				'no'   => __( 'Disable', 'bloga' ),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_filter_style',
			[
				'label' => __( 'Filter Style', 'bloga' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'filter_color',
			[
				'label'     => __( 'Filter Color', 'bloga' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#5c6c82',
				'selectors' => [
					'{{WRAPPER}} .xl-portfolio .portfolio-filter li' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'filter_bg_color',
			[
				'label'     => __( 'Filter Background Color', 'bloga' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ef6767',
				'selectors' => [
					'{{WRAPPER}} .xl-portfolio .portfolio-filter li.mixitup-control-active' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .xl-portfolio .portfolio-filter li:hover' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .xl-portfolio .portfolio-filter li' => 'border: 1px solid {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'filter_active_color',
			[
				'label'     => __( 'Filter Hover/Active Color', 'bloga' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => [
					'{{WRAPPER}} .xl-portfolio .portfolio-filter li.mixitup-control-active' => 'color: {{VALUE}};',
					'{{WRAPPER}} .xl-portfolio .portfolio-filter li:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
				[
					'name'     => 'filter_typography',
					'label'    => __( 'Filter Typography', 'bloga' ),
					'scheme'   => Scheme_Typography::TYPOGRAPHY_4,
					'selector' => '{{WRAPPER}} .xl-portfolio .portfolio-filter li',
				]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_style',
			[
				'label' => __( 'Content Style', 'bloga' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'overlay_color',
			[
				'label'     => __( 'Item Overlay Color', 'bloga' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(0, 0, 0, 0.6)',
				'selectors' => [
					'{{WRAPPER}} .xl-portfolio figure.overlay:hover:before'  => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'content_color',
			[
				'label'     => __( 'Content Color', 'bloga' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => [
					'{{WRAPPER}} .xl-portfolio .portfolio-content .title'  => 'color: {{VALUE}};',
					'{{WRAPPER}} .xl-portfolio .portfolio-content p'  => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_bg_color',
			[
				'label'     => __( 'Icon BG Color', 'bloga' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => [
					'{{WRAPPER}} .xl-portfolio .link-icon a'  => 'background: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label'     => __( 'Icon Color', 'bloga' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#2b3747',
				'selectors' => [
					'{{WRAPPER}} .xl-portfolio .link-icon a'  => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
				[
					'name'     => 'title_font',
					'scheme'   => Scheme_Typography::TYPOGRAPHY_4,
					'selector' => '{{WRAPPER}} .xl-portfolio .portfolio-content .title',
					'fields_options' => [
						'typography' => [
							'label' => __( 'Title Font', 'bloga' ),
						],
					],
				]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
				[
					'name'     => 'skills_font',
					'scheme'   => Scheme_Typography::TYPOGRAPHY_4,
					'selector' => '{{WRAPPER}} .xl-portfolio .portfolio-content .xl-skills',
					'fields_options' => [
						'typography' => [
							'label' => __( 'Skills Font', 'bloga' ),
						],
					],
				]
		);

		$this->end_controls_section();
	}

	protected function render() {
		require BLOGA_CORE_ROOT . '/elements/xl-portfolio/template/view.php';
	}


}
