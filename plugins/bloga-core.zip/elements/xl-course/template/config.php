<?php


use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Course
 *
 * Elementor widget for Course
 *
 * @since 1.0.0
 */
class xl_course_widget extends Widget_Base {

    public function get_name() {
        return 'xl-course';
    }

    public function get_title() {
        return __( 'Course', 'bloga' );
    }

    public function get_icon() {
        return 'eicon-parallax';
    }

    public function get_categories() {
        return [ 'bloga' ];
    }

    /**
     * A list of scripts that the widgets is depended in
     * @since 1.3.0
     **/
    public function get_script_depends() {
        return [ 'xl-course' ];
    }

//    protected function _register_controls() {
//
//        $this->start_controls_section(
//            'section_style',
//            [
//                'label' => __( 'Course Options', 'bloga' ),
//                'tab'   => Controls_Manager::TAB_STYLE,
//            ]
//        );
//
//        $this->add_control(
//            'course_items',
//            [
//                'label'     => __( 'Course Items to Show', 'bloga' ),
//                'type'      => Controls_Manager::SELECT,
//                'default'   => '3',
//                'options'   => [
//                    '1'   => __( 'Item 1', 'bloga' ),
//                    '2'   => __( 'Item 2', 'bloga' ),
//                    '3'   => __( 'Item 3', 'bloga' ),
//                ],
//            ]
//        );
//        $this->end_controls_section();
//
//    }

    protected function render() {
        require BLOGA_CORE_ROOT . '/elements/xl-course/template/view.php';
    }
}
