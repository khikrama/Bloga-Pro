<?php

// Register Custom Post Type
function xl_testimonials()
{

    $labels = array(
        'name' => _x('Testimonials', 'Post Type General Name', 'bloga'),
        'singular_name' => _x('Testimonial', 'Post Type Singular Name', 'bloga'),
        'menu_name' => __('Testimonial', 'bloga'),
        'name_admin_bar' => __('Testimonial', 'bloga'),
        'archives' => __('Testimonial Archives', 'bloga'),
        'attributes' => __('Testimonial Attributes', 'bloga'),
        'parent_item_colon' => __('Parent Testimonial:', 'bloga'),
        'all_items' => __('All Testimonials', 'bloga'),
        'add_new_item' => __('Add New Testimonial', 'bloga'),
        'add_new' => __('Add New', 'bloga'),
        'new_item' => __('New Testimonial', 'bloga'),
        'edit_item' => __('Edit Testimonial', 'bloga'),
        'update_item' => __('Update Testimonial', 'bloga'),
        'view_item' => __('View Testimonial', 'bloga'),
        'view_items' => __('View Testimonials', 'bloga'),
        'search_items' => __('Search Testimonial', 'bloga'),
        'not_found' => __('Not found', 'bloga'),
        'not_found_in_trash' => __('Not found in Trash', 'bloga'),
        'featured_image' => __('Featured Image', 'bloga'),
        'set_featured_image' => __('Set featured image', 'bloga'),
        'remove_featured_image' => __('Remove featured image', 'bloga'),
        'use_featured_image' => __('Use as featured image', 'bloga'),
        'insert_into_item' => __('Insert into testimonial', 'bloga'),
        'uploaded_to_this_item' => __('Uploaded to this testimonial', 'bloga'),
        'items_list' => __('Testimonials list', 'bloga'),
        'items_list_navigation' => __('Testimonials list navigation', 'bloga'),
        'filter_items_list' => __('Filter testimonial list', 'bloga'),
    );
    $args = array(
        'label' => __('Testimonial', 'bloga'),
        'description' => __('Testimonial post type', 'bloga'),
        'labels' => $labels,
        'supports' => array('title', 'editor', 'revisions', ),
        // 'taxonomies' => array('category', 'post_tag'),
        'hierarchical' => true,
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 7,
        'menu_icon' => 'dashicons-testimonial',
        'show_in_admin_bar' => true,
        'show_in_nav_menus' => true,
        'can_export' => true,
        'has_archive' => true,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'capability_type' => 'page',
    );
    register_post_type('testimonial', $args);

}
add_action('init', 'xl_testimonials', 0);