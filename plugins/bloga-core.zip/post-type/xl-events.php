<?php

// Register Custom Post Type
function xl_events()
{

    $labels = array(
        'name' => _x('Events', 'Post Type General Name', 'bloga'),
        'singular_name' => _x('Event', 'Post Type Singular Name', 'bloga'),
        'menu_name' => __('Events', 'bloga'),
        'name_admin_bar' => __('Event', 'bloga'),
        'archives' => __('Event Archives', 'bloga'),
        'attributes' => __('Event Attributes', 'bloga'),
        'parent_item_colon' => __('Parent Event:', 'bloga'),
        'all_items' => __('All Events', 'bloga'),
        'add_new_item' => __('Add New Event', 'bloga'),
        'add_new' => __('Add New', 'bloga'),
        'new_item' => __('New Event', 'bloga'),
        'edit_item' => __('Edit Event', 'bloga'),
        'update_item' => __('Update Event', 'bloga'),
        'view_item' => __('View Event', 'bloga'),
        'view_items' => __('View Events', 'bloga'),
        'search_items' => __('Search Event', 'bloga'),
        'not_found' => __('Not found', 'bloga'),
        'not_found_in_trash' => __('Not found in Trash', 'bloga'),
        'featured_image' => __('Featured Image', 'bloga'),
        'set_featured_image' => __('Set featured image', 'bloga'),
        'remove_featured_image' => __('Remove featured image', 'bloga'),
        'use_featured_image' => __('Use as featured image', 'bloga'),
        'insert_into_item' => __('Insert into Event', 'bloga'),
        'uploaded_to_this_item' => __('Uploaded to this Event', 'bloga'),
        'items_list' => __('Events list', 'bloga'),
        'items_list_navigation' => __('Events list navigation', 'bloga'),
        'filter_items_list' => __('Filter event list', 'bloga'),
    );
    $args = array(
        'label' => __('Event', 'bloga'),
        'description' => __('Event post type', 'bloga'),
        'labels' => $labels,
        'supports' => array('title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', ),
        'taxonomies' => array('category', 'post_tag'),
        'hierarchical' => true,
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 6,
        'menu_icon' => 'dashicons-calendar-alt',
        'show_in_admin_bar' => true,
        'show_in_nav_menus' => true,
        'can_export' => true,
        'has_archive' => true,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'capability_type' => 'page',
    );
    register_post_type('event', $args);

}
add_action('init', 'xl_events', 0);