<?php

// Register Custom Post Type
function xl_courses() {

    $labels = array(
        'name'                  => _x( 'Courses', 'Post Type General Name', 'bloga' ),
        'singular_name'         => _x( 'Course', 'Post Type Singular Name', 'bloga' ),
        'menu_name'             => __( 'Courses', 'bloga' ),
        'name_admin_bar'        => __( 'Course', 'bloga' ),
        'archives'              => __( 'Course Archives', 'bloga' ),
        'attributes'            => __( 'Course Attributes', 'bloga' ),
        'parent_item_colon'     => __( 'Parent Course:', 'bloga' ),
        'all_items'             => __( 'All Courses', 'bloga' ),
        'add_new_item'          => __( 'Add New Course', 'bloga' ),
        'add_new'               => __( 'Add New', 'bloga' ),
        'new_item'              => __( 'New Course', 'bloga' ),
        'edit_item'             => __( 'Edit Course', 'bloga' ),
        'update_item'           => __( 'Update Course', 'bloga' ),
        'view_item'             => __( 'View Course', 'bloga' ),
        'view_items'            => __( 'View Courses', 'bloga' ),
        'search_items'          => __( 'Search Course', 'bloga' ),
        'not_found'             => __( 'Not found', 'bloga' ),
        'not_found_in_trash'    => __( 'Not found in Trash', 'bloga' ),
        'featured_image'        => __( 'Featured Image', 'bloga' ),
        'set_featured_image'    => __( 'Set featured image', 'bloga' ),
        'remove_featured_image' => __( 'Remove featured image', 'bloga' ),
        'use_featured_image'    => __( 'Use as featured image', 'bloga' ),
        'insert_into_item'      => __( 'Insert into course', 'bloga' ),
        'uploaded_to_this_item' => __( 'Uploaded to this course', 'bloga' ),
        'items_list'            => __( 'Courses list', 'bloga' ),
        'items_list_navigation' => __( 'Courses list navigation', 'bloga' ),
        'filter_items_list'     => __( 'Filter course list', 'bloga' ),
    );
    $args = array(
        'label'                 => __( 'Course', 'bloga' ),
        'description'           => __( 'Course post type', 'bloga' ),
        'labels'                => $labels,
        'supports'              => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', ),
        'taxonomies'            => array( 'category', 'post_tag' ),
        'hierarchical'          => true,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-welcome-learn-more',
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'page',
    );
    register_post_type( 'course', $args );

}
add_action( 'init', 'xl_courses', 0 );