<?php

// Register Custom Post Type
function xl_element_anywhere()
{

    $labels = array(
        'name' => _x('XL Global Templates', 'Post Type General Name', 'bloga'),
        'singular_name' => _x('XL Template', 'Post Type Singular Name', 'bloga'),
        'menu_name' => __('XL Templates', 'bloga'),
        'name_admin_bar' => __('XL Templates', 'bloga'),
        'archives' => __('List Archives', 'bloga'),
        'parent_item_colon' => __('Parent List:', 'bloga'),
        'all_items' => __('All XL Templates', 'bloga'),
        'add_new_item' => __('Add New XL Template', 'bloga'),
        'add_new' => __('Add New', 'bloga'),
        'new_item' => __('New XL Template', 'bloga'),
        'edit_item' => __('Edit XL Template', 'bloga'),
        'update_item' => __('Update XL Template', 'bloga'),
        'view_item' => __('View XL Template', 'bloga'),
        'search_items' => __('Search XL Template', 'bloga'),
        'not_found' => __('Not found', 'bloga'),
        'not_found_in_trash' => __('Not found in Trash', 'bloga')
    );
    $args = array(
        'label' => __('Post List', 'bloga'),
        'labels' => $labels,
        'supports' => array('title', 'editor'),
        'public' => true,
        'rewrite' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => false,
        'exclude_from_search' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu-icon' => 'dashicon-move'
    );
    register_post_type('xl_element_anywhere_templates', $args);

}
add_action('init', 'xl_element_anywhere', 0);