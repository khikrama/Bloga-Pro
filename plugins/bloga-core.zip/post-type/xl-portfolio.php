<?php
/**
 * Portfolio
 **/

function xl_portfolio(){
    $labels = array(
        'name' => __('Portfolio',  'bloga'),
        'singular_name' => __('Portfolio',  'bloga'),
        'menu_name' => __('Portfolio', 'bloga'),
        'parent_item_colon' => __('Parent Portfolio:', 'bloga'),
        'all_items' => __('All Portfolio', 'bloga'),
        'view_item' => __('View Portfolio', 'bloga'),
        'add_new_item' => __('Add New Portfolio', 'bloga'),
        'add_new' => __('New Portfolio', 'bloga'),
        'edit_item' => __('Edit Portfolio', 'bloga'),
        'update_item' => __('Update Portfolio', 'bloga'),
        'search_items' => __('Search Porftolio', 'bloga'),
        'not_found' => __('No Portfolio found', 'bloga'),
        'not_found_in_trash' => __('No Porftolio found in Trash', 'bloga'),
    );
    $args = array(
        'label' => __('Portfolio', 'bloga'),
        'description' => __('Portfolio', 'bloga'),
        'labels' => $labels,
        'supports' => array('title'),
        'hierarchical' => false,
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'show_in_admin_bar' => true,
        'menu_position' => 5,
        'menu_icon' => 'dashicons-screenoptions',
        'can_export' => true,
        'has_archive' => false,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'supports'  => array( 'title', 'editor', 'revisions' ),
        'capability_type' => 'page',
    );
    register_post_type('portfolio', $args);
}

add_action('init', 'xl_portfolio');

// Filter
function xl_portfolio_filter(){
    $labels = array(
        'name' => __( 'Portfolio Filters', 'bloga' ),
        'singular_name' => __( 'Portfolio Filter', 'bloga' ),
        'search_items' => __( 'Search Filters', 'bloga' ),
        'popular_items' => __( 'Popular Filters', 'bloga' ),
        'all_items' => __( 'All Filters', 'bloga' ),
        'parent_item' => __( 'Parent Filter', 'bloga' ),
        'parent_item_colon' => __( 'Parent Filter:', 'bloga' ),
        'edit_item' => __( 'Edit Filter', 'bloga' ),
        'update_item' => __( 'Update Filter', 'bloga' ),
        'add_new_item' => __( 'Add New Filter', 'bloga' ),
        'new_item_name' => __( 'New Filter', 'bloga' ),
        'separate_items_with_commas' => __( 'Separate Filters with commas', 'bloga' ),
        'add_or_remove_items' => __( 'Add or remove Filters', 'bloga' ),
        'choose_from_most_used' => __( 'Choose from the most used Filters', 'bloga' ),
        'menu_name' => __( 'Filters', 'bloga' ),
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'show_in_nav_menus' => false,
        'show_ui' => true,
        'show_tagcloud' => false,
        'hierarchical' => true,
        'rewrite' => true,
        'query_var' => true
    );

    register_taxonomy( 'filters', array('portfolio'), $args );
}
add_action('init', 'xl_portfolio_filter');

