<?php
/*
Plugin Name: Bloga Pro Core
Description: Huge collection of custom widgets, neatly bundled into a single plugin. It's also a framework to code your own widgets to help you make any kind of page.
Version: 1.1
Text Domain: bloga
Domain Path: bloga/languages
Author: XLTHEME
Author URI: https://www.xltheme.com/
Plugin URI: http://www.xltheme.com/
License: GPL3
License URI: https://www.gnu.org/licenses/gpl-3.0.txt
*/

define('BLOGA_BUNDLE_BASE_FILE', __FILE__);
define( 'BLOGA_CORE_ROOT', untrailingslashit( plugin_dir_path( __FILE__ ) ) );


function xl_bloga_core_script() {
    
        if (!is_admin()) {
            wp_enqueue_style('xl_custom_css', plugins_url('/assets/css/xl-style.css', __FILE__), array(), '1.0.0');
        }
    }
    
    add_action('init', 'xl_bloga_core_script');


// Meta boxes
// Page
require_once BLOGA_CORE_ROOT . '/metabox/xl-meta-page.php';


// Elemontor Widget
// Slider
require_once BLOGA_CORE_ROOT . '/elements/xl-slider/plugin.php';
// Blog
require_once BLOGA_CORE_ROOT . '/elements/xl-blog/plugin.php';

// Helper Functions
require_once BLOGA_CORE_ROOT . '/elements/helper-functions.php';