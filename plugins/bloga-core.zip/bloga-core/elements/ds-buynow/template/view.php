<?php
$settings = $this->get_settings();
?>

<div class="row">
    <div class="buynow-section">
        <div class="buynow-text col-md-8">
            <?php echo $settings['buynow_text'];?>
        </div>
        <div class="buynow-button col-md-4">

            <?php if ( ! empty( $settings['buynow_btn']['url'] ) ) : ?>
                <?php
                $this->add_render_attribute( 'buynow_btn', 'src', $settings['buynow_btn']['url'] );
                $image_html = '<img ' . $this->get_render_attribute_string( 'buynow_btn' ) . '>';
                ?>

                <a href="<?php echo $settings['buynow_link'];?>">
                    <?php echo $image_html; ?>
                </a>

                <?php else:?>

                <a href="<?php echo $settings['buynow_link'];?>"><img src="<?php echo plugins_url('/assets/buynow.png', __FILE__); ?>" alt="Buy Now"></a>

            <?php endif;?>
        </div>
    </div>
</div>

