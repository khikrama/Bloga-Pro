<?php


use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Buy Now
 *
 * Elementor widget for Buy Now
 *
 * @since 1.0.0
 */
class ds_buynow_widget extends Widget_Base {

    public function get_name() {
        return 'tbpa-ds-buynow';
    }

    public function get_title() {
        return __( 'Buy Now', 'bloga' );
    }

    public function get_icon() {
        return 'eicon-parallax';
    }

    public function get_categories() {
        return [ 'tbpa' ];
    }

    /**
     * A list of scripts that the widgets is depended in
     * @since 1.3.0
     **/
    public function get_script_depends() {
        return [ 'tbpa-ds-buynow' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'buynow_text_section',
            [
                'label' => __( 'Buy Now', 'bloga' ),
            ]
        );

        $this->add_control(
            'buynow_text',
            [
                'label' => __( 'Buy Now Text', 'bloga' ),
                'type'  => Controls_Manager::TEXTAREA,
                'default' => __( 'ISBN & BAR CODE SERVICE - £17 plus vat', 'bloga' ),
            ]
        );

        $this->add_control(
            'buynow_btn',
            [
                'label' => __( 'Button Image', 'bloga' ),
                'type'  => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'buynow_link',
            [
                'label' => __( 'Buy Now Link', 'bloga' ),
                'type'  => Controls_Manager::TEXT,
                'default' => __( '#', 'bloga' ),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'buynow_text_style',
            [
                'label' => __( 'BuyNow Text Options', 'bloga' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'buynow_typography',
                'label'    => __( 'Typography', 'bloga' ),
                'scheme'   => Scheme_Typography::TYPOGRAPHY_4,
                'selector' => '{{WRAPPER}} .buynow-section .buynow-text',
            ]
        );
        $this->add_control(
            'buynow_text_align',
            [
                'label'     => __( 'Text Alignment', 'bloga' ),
                'type'      => Controls_Manager::CHOOSE,
                'default'   => 'center',
                'options'   => [
                    'left'    => [
                        'title' => __( 'Left', 'elementor' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'elementor' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'elementor' ),
                        'icon' => 'fa fa-align-right',
                    ],
                    'justify' => [
                        'title' => __( 'Justified', 'elementor' ),
                        'icon' => 'fa fa-align-justify',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .buynow-section .buynow-text' => 'text-align: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_section();


        $this->start_controls_section(
            'buynow_btn_style',
            [
                'label' => __( 'BuyNow Button Options', 'bloga' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'buynow_btn_align',
            [
                'label'     => __( 'Button Alignment', 'bloga' ),
                'type'      => Controls_Manager::CHOOSE,
                'default'   => 'center',
                'options'   => [
                    'left'    => [
                        'title' => __( 'Left', 'elementor' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'elementor' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'elementor' ),
                        'icon' => 'fa fa-align-right',
                    ],
                    'justify' => [
                        'title' => __( 'Justified', 'elementor' ),
                        'icon' => 'fa fa-align-justify',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .buynow-section .buynow-button' => 'text-align: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_section();

    }

    protected function render() {
        require TBPA_CORE_ROOT . '/elements/ds-buynow/template/view.php';
    }
}
