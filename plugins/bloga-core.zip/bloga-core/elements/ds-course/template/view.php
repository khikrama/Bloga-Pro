<?php
$settings = $this->get_settings();
?>

<div class="course-wraper">
    <div class="row">
        <?php
            $course = array(
                'post_type'         => 'course',
                'post_status'       => 'publish',
                'posts_per_page'    => -1,
            );
            $course_query = new WP_Query( $course );
            if($course_query->have_posts()):
            while($course_query->have_posts()):
            $course_query->the_post();
        ?>
        <div class="col-md-4">
            <div class="ds-course">
                <div class="thumb-title">
                    <?php if ( has_post_thumbnail() ) {
                        the_post_thumbnail();
                    } else { ?>
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/course-placeholder.jpg" alt="<?php the_title(); ?>" />
                    <?php } ?>

                    <h2 class="title"><?php echo the_title(); ?></h2>
                </div><!--/.thumb-title-->
                <div class="info">
                    <div class="discription">
                        <?php echo the_excerpt(); ?>
                    </div>
                    <a href="<?php echo the_permalink(); ?>" class="btn btn-course elementor-button">Learn More</a>
                </div><!--/.info-->
            </div><!--/.single-course-->
        </div><!--/.col-md-4-->
        <?php endwhile; endif; wp_reset_postdata(); ?>

    </div>
</div>