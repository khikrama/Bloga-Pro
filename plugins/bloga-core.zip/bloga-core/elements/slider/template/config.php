<?php


use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Switch Slider
 *
 * Elementor widget for switch slider
 *
 * @since 1.0.0
 */
class tbpa_slider extends Widget_Base {

	public function get_name() {
		return 'tbpa-slider';
	} 

	public function get_title() {
		return __( 'Testimonial Slider', 'bloga' );
	}

	public function get_icon() {
		return 'eicon-slider-video';
	}

	public function get_categories() {
		return [ 'tbpa' ];
	}

	/**
	 * A list of scripts that the widgets is depended in
	 * @since 1.3.0
	 **/
	public function get_script_depends() {
		return [ 'tbpa-slider' ];
	}

	protected function _register_controls() {

	// Content options Start
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Slider Content', 'bloga' ),
			]
		);


	$repeater = new Repeater();
	    $repeater->add_control(
		    'title',
		      	[
		          'label' => __( 'Slider Title', 'bloga' ),
		          'type'  => Controls_Manager::TEXTAREA,
		          'default' => __( 'Testimonial from Jonathan Morgan:', 'bloga' ),
		    	]
	    );


        $repeater->add_control(
            'author_name',
            [
                'label' => __( 'Author Name', 'bloga' ),
                'type'  => Controls_Manager::TEXT,
                'default' => __( 'Jonathan Morgan', 'bloga' ),
            ]
        );
        $repeater->add_control(
            'author_designation',
            [
                'label' => __( 'Author Designation', 'bloga' ),
                'type'  => Controls_Manager::TEXT,
                'default' => __( 'Best-selling UK based published author', 'bloga' ),
            ]
        );
		$repeater->add_control(
	       'author_image',
		        [
		          'label' => __( 'Upload Author Image', 'bloga' ),
		          'type'  => Controls_Manager::MEDIA
		        ]
	    );
        $repeater->add_control(
            'author_book_image',
            [
                'label' => __( 'Upload Book Image', 'bloga' ),
                'type'  => Controls_Manager::MEDIA
            ]
        );
        $repeater->add_control(
            'amazon_image',
            [
                'label' => __( 'Upload Amazon Image', 'bloga' ),
                'type'  => Controls_Manager::MEDIA
            ]
        );

		$repeater->add_control(
		    'slider_content',
		      	[
		          'label' => __( 'Slider Description', 'bloga' ),
		          'type'  => Controls_Manager::WYSIWYG,
		          'default' => __( 'Corem ipsum dolor si amet consectetur adipisic ingelit sed do adipisicido executiv
						sunse pit lore kome.', 'bloga' ),
		      	]
		);



		$this->add_control(
		    'slider_option',
		      [
		          'label'       => __( 'Slider Options', 'bloga' ),
		          'type'        => Controls_Manager::REPEATER,
		          'show_label'  => true,
		          'default'     => [
		              [
		                'title' => __( 'Testimonial from Jonathan Morgan:', 'bloga' ),
		                'slider_content' => 'Enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo conse quat. Duis aute irure dolor in reprehenderit in voluptate.',
		 
		              ]
		          ],
		          'fields'      => array_values( $repeater->get_controls() ),
		          'title_field' => '{{{title}}}',
		      ]
		  );

$this->end_controls_section();
// Content options End




// Control options Start
        $this->start_controls_section(
            'control_style',
            [
                'label' => __( 'Control Options', 'switch_pro' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );


        $this->start_controls_tabs( 'slider_control' );

        $this->start_controls_tab(
            'Background Options',
            [
                'label' => __( 'Background', 'switch_pro' ),
            ]
        );

        $this->add_control(
            'slider_interval',
            [
                'label' => __( 'Slider Interval', 'switch_pro' ),
                'type' => Controls_Manager::TEXT,
                'default' => '10000',
            ]
        );



        $this->add_control(
            'bg_repeat',
            [
                'label'     => __( 'Item Background Repeat', 'switch_pro' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'no-repeat',
                'options'   => [
                    'no-repeat'  => __( 'No Repeat', 'switch_pro' ),
                    'repeat'     => __( 'Repeat', 'switch_pro' ),
                    'repeat-x'   => __( 'Repeat X', 'switch_pro' ),
                    'repeat-y'   => __( 'Repeat Y', 'switch_pro' ),
                    'inherit'    => __( 'Inherit', 'switch_pro' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .switch-hero-unit .carousel .item' => 'background-repeat: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'bg_size',
            [
                'label'     => __( 'Item Background Size', 'switch_pro' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'cover',
                'options'   => [
                    'cover'     => __( 'Cover', 'switch_pro' ),
                    'contain'   => __( 'Contain', 'switch_pro' ),
                    'inherit'   => __( 'Inherit', 'switch_pro' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .switch-hero-unit .carousel .item' => 'background-size: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'bg_attachment',
            [
                'label'     => __( 'Item Background Attachment', 'switch_pro' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'fixed',
                'options'   => [
                    'fixed'    => __( 'fixed', 'switch_pro' ),
                    'inherit'  => __( 'Inherit', 'switch_pro' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .switch-hero-unit .carousel .item' => 'background-attachment: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'slider_nav',
            [
                'label' => __( 'Nav Options', 'switch_pro' ),
            ]
        );

        $this->add_control(
            'nav_enable',
            [
                'label'     => __( 'Nav Enable/Disable', 'switch_pro' ),
                'type'      => Controls_Manager::SWITCHER,
                'default'   => 'yes',
                'enable'    => __( 'Enable', 'switch_pro' ),
                'disable'   => __( 'Disable', 'switch_pro' ),
            ]
        );

        $this->add_control(
            'arrow_enable',
            [
                'label'     => __( 'Arrow Enable/Disable', 'switch_pro' ),
                'type'      => Controls_Manager::SWITCHER,
                'default'   => 'yes',
                'enable'    => __( 'Enable', 'switch_pro' ),
                'disable'   => __( 'Disable', 'switch_pro' ),
            ]
        );

        $this->add_control(
            'nav_color',
            [
                'label'     => __( 'Nav & Arrow Icon Color', 'switch_pro' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .switch-hero-unit .carousel .carousel-control i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .switch-hero-unit .carousel .carousel-indicators li' => 'background-color:{{VALUE}};',
                    '{{WRAPPER}} .switch-hero-unit .carousel .carousel-control' => 'border:1px solid {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'nav_bg_color',
            [
                'label'     => __( 'Nav & Arrow Bg Color', 'switch_pro' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#8651e7',
                'selectors' => [
                    '{{WRAPPER}} .switch-hero-unit .carousel .carousel-indicators>li.active' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .switch-hero-unit .carousel .carousel-indicators li.active' => 'border:1px solid {{VALUE}};',
                    '{{WRAPPER}} .switch-hero-unit  .carousel-control:hover' => 'border-color: {{VALUE}} !important;',
                    '{{WRAPPER}} .switch-hero-unit .carousel .carousel-control:hover' => 'background-color:{{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
// Control options End



	}

	protected function render() {
		require TBPA_CORE_ROOT . '/elements/slider/template/view.php';
	}


}
