<?php
// Silence is golden.

    $settings = $this->get_settings();

?>

    <section id="switch-hero-unit" class="switch-hero-unit">
        <div id="switch-slider" class="switch-slider carousel slide" data-ride="carousel" data-interval="
         <?php if ($settings['slider_interval']):
             echo $settings['slider_interval'];
         endif; ?>
        ">
             <?php if ($settings['nav_enable']):?>
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <?php for($i = 0; $i < count($settings['slider_option']); $i++):
                        $active = $i == 0 ? 'active' : '';?>
                    <li data-target="#switch-slider" data-slide-to="<?php echo $i;?>" class="<?php echo $active;?>"></li>
                    <?php endfor; ?>
                </ol>
            <?php endif; ?>
            <!-- Wrapper for slides -->
            <div class="carousel-inner ">
                  <?php  $i = 0;?>
                <?php foreach ( $settings['slider_option'] as $slider ) : ?>
                    <?php $active = $i == 0 ? 'active' : ''; ?>
                    <div class="item <?php echo $active;?> slider-<?php echo $i;?>">


                        <div class="single-testi">
                            <?php if ($slider['title']):?>
                            <div class="title">
                                <h2 class="text-center"><?php echo $slider['title']; ?></h2>
                                <div class="border-bottom"></div>
                            </div>
                            <?php endif; ?>

                            <div class="content clearfix">
                                <?php if ($slider['author_image']['url']):?>
                                <div class="author-img">
                                    <img src="<?php echo $slider['author_image']['url'];?>" alt="author"/>
                                </div><!--/.author-img-->
                                <?php endif; ?>

                                <div class="author-content">
                                    <p><?php echo $slider['slider_content']; ?></p>
                                    <div class="name-book row">
                                        <div class="col-sm-7 name-deg">
                                            <div class="name">
                                                <?php echo $slider['author_name'];?>
                                            </div>
                                            <div class="deg">
                                                <?php echo $slider['author_designation'];?>
                                            </div>
                                        </div><!--/.name-deg-->

                                        <?php if ($slider['amazon_image']['url']):?>
                                        <div class="col-sm-5 book text-right">
                                            <img src="<?php echo $slider['amazon_image']['url'];?>" alt="amazon"/>
                                        </div><!--/.book-->
                                        <?php endif;?>
                                    </div><!--/.name-book-->
                                </div><!--/.author-content-->

                                <?php if ($slider['author_book_image']['url']):?>
                                <div class="book-img">
                                    <img src="<?php echo $slider['author_book_image']['url'];?>" alt="book"/>
                                </div><!--/.book-img-->
                                <?php endif;?>
                            </div>
                        </div><!--/.single-testi-->


                    </div><!-- /.item -->

                <?php  $i++; endforeach; ?>

                </div> <!-- /.inner -->
                <?php if ($settings['arrow_enable']):?>
                    <a class="left" href="#switch-slider" data-slide="prev">
                        <span class="left-img">Previous</span>
                    </a>
                    <a class="right" href="#switch-slider" data-slide="next">
                        <span class="right-img">Next</span>
                    </a>
                <?php endif; ?>

        </div><!-- /.id -->
    </section> <!-- /#hero-unit -->
<?php
