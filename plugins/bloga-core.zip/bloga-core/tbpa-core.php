<?php
/*
Plugin Name: TBPA Core
Description: Huge collection of custom widgets, neatly bundled into a single plugin. It's also a framework to code your own widgets to help you make any kind of page.
Version: 1.0.1
Text Domain: bloga
Domain Path: tbpa/languages
Author: XLTHEME
Author URI: https://www.xltheme.com/
Plugin URI: http://www.xltheme.com/
License: GPL3
License URI: https://www.gnu.org/licenses/gpl-3.0.txt
*/

define('TBPA_BUNDLE_BASE_FILE', __FILE__);
define( 'TBPA_CORE_ROOT', untrailingslashit( plugin_dir_path( __FILE__ ) ) );




// Meta boxes


// Post types
// Course
require_once TBPA_CORE_ROOT . '/post-type/ds-courses.php';



// Elemontor Widget

// Course
require_once TBPA_CORE_ROOT . '/elements/ds-course/plugin.php';

// Course
require_once TBPA_CORE_ROOT . '/elements/ds-buynow/plugin.php';

// Author Testimonial
require_once TBPA_CORE_ROOT . '/elements/slider/plugin.php';


// Helper Functions
require_once TBPA_CORE_ROOT . '/elements/helper-functions.php';


