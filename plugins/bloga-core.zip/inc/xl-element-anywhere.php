<?php

require_once( BLOGA_CORE_ROOT . '/post-type/xl-element-anywhere.php' );
require_once( BLOGA_CORE_ROOT . '/metabox/xl-element-anywhere.php' );
require_once( BLOGA_CORE_ROOT . '/inc/functions/xl-element-anywhere.php' );




function xl_element_anywhere_styles_method() {
    $custom_css = "<style type='text/css'> .xl_data .elementor-editor-element-setting {
                        display:none !important;
                }
                </style>";
    echo $custom_css;
}
add_action( 'wp_head', 'xl_element_anywhere_styles_method' );
