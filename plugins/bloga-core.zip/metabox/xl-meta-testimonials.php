<?php

/**
 * Include and setup custom metaboxes and fields. (make sure you copy this file to outside the CMB2 directory)
 *
 * Be sure to replace all instances of 'yourprefix_' with your project's prefix.
 * http://nacin.com/2010/05/11/in-wordpress-prefix-everything/
 *
 * @category YourThemeOrPlugin
 * @package  Demo_CMB2
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     https://github.com/WebDevStudios/CMB2
 */


function xl_bloga_all_metabox()
{
    $prefix = '_xl_';
    
    // Testimonial options
    $testimonials = new_cmb2_box(
        array(
            'id' => 'testimonial',
            'title' => __('Testimonial Details', "bloga"),
            'object_types' => array('testimonial'), // post type
            'context' => 'side',
            'priority' => 'high',
            'show_names' => true, // Show field names on the left
            'fields' => array(
                array(
                    'name' => __('Testimonial Image ', "bloga"),
                    'id' => $prefix . 'testimoni_image',
                    'type' => 'file',
                    // 'default' => get_template_directory_uri() . '/dist/images/testimonial/testimonial-1.png',
                ),
                array(
                    'name' => __('Name of the Person ', "bloga"),
                    'id' => $prefix . 'testimoni_name',
                    'type' => 'text_medium',
                    'default' => 'Juliana Anderson'
                ),
                array(
                    'name' => __('Designation', "bloga"),
                    'id' => $prefix . 'testimoni_designation',
                    'type' => 'text_medium',
                    'default' => 'Designer'
                ),
            )
        )
    );

    // Portfolio image options
    $portfolio_image = new_cmb2_box(
        array(
            'id'           => 'portfolio',
            'title'        => __('Portfolio Information',"bloga"),
            'object_types' => array('portfolio'), // post type
            'context'      => 'normal',
            'priority'     => 'high',
            'show_names'   => true, // Show field names on the left
            'fields' => array(
                array(
                    'name'    => __('Portfolio Thumbnail Image',"bloga"),
                    'id'      => $prefix . 'portfolio_img',
                    'type'    => 'file',
                ),
                array(
                    'name'    => __('Portfolio Large Image',"bloga"),
                    'id'      => $prefix . 'large_portfolio_img',
                    'type'    => 'file',
                ),
//                array(
//                    'name'    => __('Single Portfolio Header Image',"bloga"),
//                    'id'      => $prefix . 'header_portfolio_img',
//                    'type'    => 'file',
//                    'default' => '',
//                ),
                array(
                    'name'    => __('Project Link',"bloga"),
                    'id'      => $prefix . 'portfolio_link',
                    'type'    => 'text_medium',
                    'default' => 'https://www.xltheme.com/'
                ),
                array(
                    'name'    => __('Skills Needed',"bloga"),
                    'id'      => $prefix . 'project_skill',
                    'type'    => 'text_medium',
                    'default' => 'html, css, js'
                ),
                array(
                    'name'    => __('Project Cost',"bloga"),
                    'id'      => $prefix . 'project_cost',
                    'type'    => 'text_medium',
                    'default' => '$5M'
                ),
                array(
                    'name'    => __('Copyright',"bloga"),
                    'id'      => $prefix . 'project_copyright',
                    'type'    => 'text_medium',
                    'default' => 'XLTHEME'
                ),

            )
        )
    );
}
add_action('cmb2_admin_init', 'xl_bloga_all_metabox');