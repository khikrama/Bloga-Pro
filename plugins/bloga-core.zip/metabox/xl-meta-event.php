<?php

/**
 * Include and setup custom metaboxes and fields. (make sure you copy this file to outside the CMB2 directory)
 *
 * Be sure to replace all instances of 'yourprefix_' with your project's prefix.
 * http://nacin.com/2010/05/11/in-wordpress-prefix-everything/
 *
 * @category YourThemeOrPlugin
 * @package  Demo_CMB2
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     https://github.com/WebDevStudios/CMB2
 */


function xl_bloga_event_metabox()
{
    $prefix = '_xl_';
    /**
     * Sample metabox to demonstrate each field type included
     */
    $cmb_event = new_cmb2_box(array(
        'id' => $prefix . 'event_info',
        'title' => esc_html__('Event Information', 'bloga'),
        'object_types' => array('event'),
        // 'context'    => 'normal',
        // 'priority'   => 'high',
    ));
    $cmb_event->add_field(array(
        'name' => esc_html__('Event Date', 'bloga'),
        'desc' => esc_html__('Insert event date.', 'bloga'),
        'id' => $prefix . 'event_date',
        'type' => 'text_date',
        // 'timezone_meta_key' => 'wiki_test_timezone',
	    'date_format' => 'l, F j, Y',
    ));
    $cmb_event->add_field(array(
        'name' => esc_html__('Event Start Time', 'bloga'),
        'desc' => esc_html__('Insert event start time.', 'bloga'),
        'id' => $prefix . 'event_start_time',
        'type' => 'text_time',
        'time_format' => 'H:i',
    ));
    $cmb_event->add_field(array(
        'name' => esc_html__('Event End Time', 'bloga'),
        'desc' => esc_html__('Insert event end time.', 'bloga'),
        'id' => $prefix . 'event_end_time',
        'type' => 'text_time',
        'time_format' => 'H:i',
    ));
    $cmb_event->add_field(array(
        'name' => esc_html__('Event Locaion', 'bloga'),
        'desc' => esc_html__('Insert event location.', 'bloga'),
        'id' => $prefix . 'event_location',
        'type' => 'text',
    ));
}
add_action('cmb2_admin_init', 'xl_bloga_event_metabox');