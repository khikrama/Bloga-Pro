<?php

// Silence is golden.
    $settings = $this->get_settings();
?>

    <section id="xl-hero-unit" class="xl-hero-unit">

        <div class="container">

            <div id="xl-slider" class="xl-slider carousel slide" data-ride="carousel" data-interval="

            <?php if ($settings['slider_interval']):

                echo $settings['slider_interval'];

            endif; ?>

            ">

                <?php if (($settings['navigation'] == 'both') || ($settings['navigation'] == 'dots')):?>

                    <!-- Indicators -->

                    <ol class="carousel-indicators">

                        <?php for($i = 0; $i < count($settings['slider_option']); $i++):

                            $active = $i == 0 ? 'active' : '';?>

                        <li data-target="#xl-slider" data-slide-to="<?php echo $i;?>" class="<?php echo $active;?>"></li>

                        <?php endfor; ?>

                    </ol>

                <?php endif; ?>

                <!-- Wrapper for slides -->

                <div class="carousel-inner ">

                    <?php  $i = 0;?>

                    <?php foreach ( $settings['slider_option'] as $slider ) : ?>

                        <?php $active = $i == 0 ? 'active' : ''; ?>

                        <div class="item <?php echo $active;?> slider-<?php echo $i;?>">

                            <div class="single-slide">

                                <?php if ($slider['title']):?>

                                    <h2 class="title"><?php echo $slider['title']; ?></h2>

                                <?php endif; ?>


                                <?php if ($slider['slider_content']):?>
                                    <div class="content">

                                        <?php echo $slider['slider_content']; ?>

                                    </div>
                                <?php endif; ?>


                                <?php if ($slider['btn_text']):?>
                                    <div class="slider-button">

                                        <a class="elementor-button btn btn-slider" href="<?php echo $slider['btn_link']['url']; ?>">

                                            <?php echo $slider['btn_text']; ?>

                                        </a>

                                    </div>
                                <?php endif; ?>

                            </div><!--/.single-testi-->

                        </div><!-- /.item -->

                        <?php  $i++; endforeach; ?>

                    </div> <!-- /.inner -->

                    <?php if (($settings['navigation'] == 'both') || ($settings['navigation'] == 'arrows')):?>

                        <div class="arrows">

                            <a class="left" href="#xl-slider" data-slide="prev">

                                <span class="left-arrow"><i class="fa fa-angle-left"></i></span>

                            </a>

                            <a class="right" href="#xl-slider" data-slide="next">

                                <span class="right-arrow"><i class="fa fa-angle-right"></i></span>

                            </a>

                        </div>

                    <?php endif; ?>

            </div><!-- /.id -->

        </div>

    </section> <!-- /#hero-unit -->

<?php

