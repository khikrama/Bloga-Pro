<?php

/**
 * Include and setup custom metaboxes and fields. (make sure you copy this file to outside the CMB2 directory)
 *
 * Be sure to replace all instances of 'yourprefix_' with your project's prefix.
 * http://nacin.com/2010/05/11/in-wordpress-prefix-everything/
 *
 * @category YourThemeOrPlugin
 * @package  Demo_CMB2
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     https://github.com/WebDevStudios/CMB2
 */


function xl_page_metabox()
{
    $prefix = '_xl_';
    /**
     * Sample metabox to demonstrate each field type included
     */
    $cmb_page_header = new_cmb2_box(array(
        'id' => $prefix . 'page_header',
        'title' => esc_html__('Page Header', 'xl'),
        'object_types' => array('page'),
        // 'context'    => 'normal',
        // 'priority'   => 'high',
    ));
    $cmb_page_header->add_field(array(
        'name' => esc_html__('Show Page Heading?', 'xl'),
        'desc' => esc_html__('Show or Hide page heading.', 'xl'),
        'id' => $prefix . 'show_title',
        'type' => 'radio_inline',
        'options' => array(
            'yes' => __('Yes', 'xl'),
            'no' => __('No', 'xl'),
        ),
        'default' => 'no',
    ));

    $cmb_page_header->add_field(array(
        'name' => esc_html__('Upload Header Image', 'xl'),
        'desc' => esc_html__('Upload your page header image.', 'xl'),
        'id' => $prefix . 'page_header_img',
        'type' => 'file',
    ));

    $cmb_page_header->add_field(array(
        'name' => esc_html__('Custom Page Title', 'xl'),
        'desc' => esc_html__('Add your custom page title.', 'xl'),
        'id' => $prefix . 'custom_page_title',
        'type' => 'text',
    ));
}
add_action('cmb2_admin_init', 'xl_page_metabox');